package com.vsam_api.openlegacy.constants;

public enum VsamFileType {
    KSDS, ESDS;
}
